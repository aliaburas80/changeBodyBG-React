var React = require("react");
var ReactDOM=require("react-dom");
var Manager = require("./components/Manager.jsx");
ReactDOM.render(<Manager btnname={"Change BG Color!"}/>,document.getElementById("component"));