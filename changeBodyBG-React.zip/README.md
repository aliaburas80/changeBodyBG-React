# changeBodyBG-React
React project, Change body background by passing color to inputbox.
